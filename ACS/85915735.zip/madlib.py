
# Homework: Create a madlib. Imagine a story where some of the words are 
# supplied by user input. Using python you will use input to collect 
# words for a story and then display the story. 

# Use input to collect each word to a variable
# Use an f string to display the story

# Your madlib must collect at least 6 words!

print("Enter the following to get a story")
fadj = input("First Adjective: ")
sadj = input("Second Adjective: ")
noun = input("Noun: ")
verb= input("Present Tense Verb: ")
noun2 = input("Second Noun: ")
place = input("Place: ")
ladj = input("Last Adjective: ")

print(f"it was a {fadj} and {sadj} night.")
print(f"I was in the woods all alone when all of a sudden I heard a {noun}.")
print(f"I was so scared and started {verb}.")
print(f"Then I ran into a {noun2}.")
print(f"They kidnapped me and took me to {place}.")
print(f"Although it was scary and {ladj}, in the end everything was fine.")

"""
it was a [adj] and [adj] night. 
I was in the woods all alone when all of a sudden I heard a [noun]. 
I was so scared and started [present tense verb]. 
Then I ran into a [noun]. 
They kidnapped me and took me to [place]. 
Although it was scary and [adj], in the end everything was fine.
"""
































# --------------------------------------------------
# Partial solution
























# name = input("Name:")
# color = input("color:")
# num = input("Number:")

# print(f"{name} wore {color} shoes while they counted to {num}")